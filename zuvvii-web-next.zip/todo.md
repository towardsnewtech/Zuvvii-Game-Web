navigating to video page works but pasting the url does not
set timestamps for cache
reload home videos if last fetch was over X time ago
improve styling of input errors (red border)
resuse themes
refactor/nest components
redirect after succesful registration
layout with navbar en top
zuvvii button with color #65C5BA and hover #76D6CB
use server side props
add tests for untested components
enter should press the login button
replace images with next/image
fix: continually queries videos if failed to fetch
Dark/Light themes
Use <Link> rather than router.push whenever possible
Video size
Make header buttons works
Improve loading animations
Autoplay next video
Profile page
Upload page
Use swc instead of babel
Some likes appear selected on generic home videos
