import * as React from 'react'

interface ISearchFriend {
    searchKey: string
}

const SearchFriend = ({
    searchKey
}: ISearchFriend) => {
    return (
        <>
        </>
    )
}

export default SearchFriend
