export const VIDEOS_PER_PAGE = 20;
