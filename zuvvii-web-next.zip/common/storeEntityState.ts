export interface StoreEntityState {
  isLoading: boolean;
  errorMessage: string;
  timestamp: Date | null;
}
