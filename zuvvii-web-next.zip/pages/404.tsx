import { Typography } from "@mui/material";
import React from "react";

export default function index() {
  return (
    <Typography
      sx={{
        color: "white",
        backgroundColor: "#171717",
        width: "100%",
        minHeight: "100vh",
      }}
    >
      WEBSITE UNDER CONSTRUCTION
    </Typography>
  );
}
